# YoutubeAdSkip 

Automatically mutes YouTube ads as soon as they appear. 
Skips ads within 1s of them appearing. 
Works on traditionally unskippable ads. 
Works with YouTube Music. 
Works on Firefox Android.

If you are using **Firefox** you can install the addons from: https://addons.mozilla.org/en-US/firefox/addon/youtubeadskip/

If you are using **Chrome** my extension submission was not approved. You can install the extension
by downloading the latest zip in the releases dir, open chrome://extensions/ in chrome, and drag the
zip into the window to install.